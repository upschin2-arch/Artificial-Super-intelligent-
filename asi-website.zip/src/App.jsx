export default function App() {
  return (
    <div style={{ 
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'Arial',
      background: '#000',
      color: '#fff'
    }}>
      <h1 style={{ fontSize: '48px', marginBottom: '10px' }}>ASI</h1>
      <h2 style={{ opacity: 0.7 }}>Artificial Super Intelligence</h2>
      <p style={{ marginTop: '20px', width: '80%', textAlign: 'center', opacity: 0.8 }}>
        The next evolution of intelligence — beyond AGI, beyond limits.
      </p>
    </div>
  )
}
